import struct

class InfoSector:
    S = struct.Struct( "<4B480b4B1I1I12B4B" )
    def __init__(self):
        self.sig = [ 0x52, 0x52, 0x61, 0x41 ]     #RRaA
        self.reserved = [0]*480 #all zero
        self.sig2 = [ 0x72,0x72,0x41,0x61]  #rrAa
        self.numFreeClusters=0xffffffff    #-1 if not known
        self.mostRecentlyAllocatedCluster=0xffffffff   #-1 if not known
        self.reserved2 = [0]*12     #all zero
        self.sig3 = [0,0,0x55,0xaa]   #0,0,0x55,0xaa
        
    def toBytes(self):
        tmp = InfoSector.S.pack( *self.sig, *self.reserved, *self.sig2, self.numFreeClusters,
            self.mostRecentlyAllocatedCluster, *self.reserved2, *self.sig3 )
        assert len(tmp) == 512
        return tmp
        
