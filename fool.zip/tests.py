

#python3 fool.py hd.img create 48 cp vbr.s vbr.s cp bootblock.py M stat vbr.s stat M dumpsector 240 dumpvbr dumpfat 0 10

import unittest
import os
import contextlib
import io
import sys
import ui

def go(*args):
    ui.go(("hd.img",)+ tuple(str(q) for q in args) )
    
def getFileSize(fname):
    with open(fname,"rb") as fp:
        fp.seek(0,2)
        return fp.tell()
        
def readFile(fname):
    with open(fname) as fp:
        return fp.read()
        
def hasFile(s, base, ext, longname, localfile):
    for line in s.split("\n"):
        if line.startswith(base+" "):
            if not line.startswith(base+" ") :
                continue
            
            if len(ext) > 0:
                idx = line.find(" ")
                while line[idx+1] == ' ':
                    idx += 1
                if not line[idx:].startswith(" "+ext ) :
                    continue
                    
            if localfile:
                if ( " {:,} ".format(getFileSize(localfile)) not in line[idx:] ):
                    continue
            if (" "+longname) not in line:
                continue
            return True
    return False   
    
def ls(d=None):
    x=io.StringIO()
    with contextlib.redirect_stdout(x):
        if d == None:
            go("ls")
        else:
            go("ls",d)
    s=x.getvalue()
    return s
     
def cat(d):
    x=io.StringIO()
    with contextlib.redirect_stdout(x):
        go("cat",d)
    s = x.getvalue()
    return s
    
class TestCreate(unittest.TestCase):
    def setUp(self):
        try:
            os.unlink("hd.img")
        except OSError:
            pass
    def tearDown(self):
        try:
            os.unlink("hd.img")
        except OSError:
            pass
    def test_create_toosmall(self):
        self.assertRaises( RuntimeError, go, "create", "20" )
        # ~ with self.assertRaises(RuntimeError):
            # ~ go("create","20")

    def test_create_ok(self):
        go("create",48)
        self.assertTrue( os.access( "hd.img", os.F_OK ) )

    def test_copy1(self):
        go("create",48,"cp","Makefile","MAKE.TXT")
        
        x=io.StringIO()
        with contextlib.redirect_stdout(x):
            go("ls")
        self.assertTrue( hasFile( x.getvalue(), "MAKE","TXT","MAKE.TXT", "Makefile" ) )
    
    def test_cat(self):
        go("create",48,"cp","Makefile","MAKE.TXT")
        go("cp","bootblock.py","bootblock.py")
        go("cp","bootblock.s","bootblock.s")
        go("cp","bootblock.py","longfilename.a")
        go("cp","bootblock.s","longfilename2.a")

        
        self.assertTrue( readFile("Makefile") in cat("MAKE.TXT") )
        self.assertTrue( readFile("bootblock.py") in cat("bootblock.py") )
        self.assertTrue( readFile("bootblock.py") in cat("BOOTBLOCK.PY") )
        self.assertTrue( readFile("bootblock.s") in cat("BOOTBLOCK.S") )
        self.assertTrue( readFile("bootblock.s") in cat("bootblock.s") )
        self.assertTrue( readFile("bootblock.py") in cat("LONGFI~1.A") )
        self.assertTrue( readFile("bootblock.s") in cat("LONGFI~2.A") )
      
    def test_copy2(self):
        
        go("create",48,"cp","Makefile","MAKE.TXT")
        go("cp","vbr.s","vbr.s")
        s = ls()
        self.assertTrue( hasFile( s, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertTrue( hasFile( s, "VBR","S","vbr.s", "vbr.s" ) )
        
    def test_mkdir2(self):
        go("create","48")
        go("mkdir","ABC")
        go("mkdir","DEF")
        s=ls()
        self.assertTrue( hasFile( s, "ABC","","ABC",None) )
        self.assertTrue( hasFile( s, "DEF","","DEF",None) )
     
    def test_mkdir3(self):
        go("create","48")
        go("mkdir","ABC")
        go("mkdir","ABC/DEF")
        
        s=ls()
        
        self.assertTrue( hasFile( s, "ABC","","ABC",None) )
        self.assertFalse( hasFile( s, "DEF","","DEF",None) )
        
        s=ls("ABC")
        
        self.assertFalse( hasFile( s, "ABC","","ABC",None) )
        self.assertTrue( hasFile( s, "DEF","","DEF",None) )
       
    def test_mkdir4(self):
        go("create","48")
        go("mkdir","ab c")
        go("mkdir","ab c/d ef")
        
        s=ls()
        
        self.assertTrue( hasFile( s, "ABC~1","","ab c",None) )
        self.assertFalse( hasFile( s, "DEF~1","","d ef",None) )
        
        s=ls("ab c")

        self.assertFalse( hasFile( s, "ABC~1","","ab c",None) )
        self.assertTrue( hasFile( s, "DEF~1","","d ef",None) )

    def test_mkdir5(self):
        go("create","48")
        go("mkdir","ab c")
        go("mkdir","ab c/d ef")
        go("cp","vbr.s","vbr.s")
        
        s=ls() 
        
        self.assertTrue( hasFile( s, "ABC~1","","ab c",None) )
        self.assertTrue( hasFile( s, "VBR","S","vbr.s","vbr.s") )
        self.assertFalse( hasFile( s, "DEF~1","","d ef",None) )
        
        s=ls("ab c")

        self.assertFalse( hasFile( s, "ABC~1","","ab c",None) )
        self.assertFalse( hasFile( s, "VBR","S","vbr.s","vbr.s") )
        self.assertTrue( hasFile( s, "DEF~1","","d ef",None) )


    def test_mkdir6(self):
        go("create","48")
        go("mkdir","ABC")
        go("mkdir","ABC/DEF")
        go("cp","vbr.s","ABC/VBR.S")
        
        s=ls("/")
        
        self.assertTrue( hasFile( s, "ABC","","ABC",None) )
        self.assertFalse( hasFile( s, "VBR","S","VBR.S","vbr.s") )
        self.assertFalse( hasFile( s, "DEF","","DEF",None) )
        
        s=ls("ABC")

        self.assertFalse( hasFile( s, "ABC","","ABC",None) )
        self.assertTrue( hasFile( s, "VBR","S","VBR.S","vbr.s") )
        self.assertTrue( hasFile( s, "DEF","","DEF",None) )


    def test_mkdir7(self):
        go("create","48")
        go("mkdir","ab c")
        go("mkdir","ab c/d ef")
        go("cp","vbr.s","ab c/vbr.s")
        
        x=io.StringIO()
        with contextlib.redirect_stdout(x):
            go("ls")
        s=x.getvalue()
        
        
        self.assertTrue( hasFile( s, "ABC~1","","ab c",None) )
        self.assertFalse( hasFile( s, "VBR","S","vbr.s","vbr.s") )
        self.assertFalse( hasFile( s, "DEF~1","","d ef",None) )
        
        x=io.StringIO()
        with contextlib.redirect_stdout(x):
            go("ls","ab c")
        s=x.getvalue()

        self.assertFalse( hasFile( s, "ABC~1","","ab c",None) )
        self.assertTrue( hasFile( s, "VBR","S","vbr.s","vbr.s") )
        self.assertTrue( hasFile( s, "DEF~1","","d ef",None) )


        
    def test_mkdir8(self):
        go("create","48")
        go("mkdir","abc")
        go("mkdir","abc/def")
        
        s = ls()
        self.assertTrue( hasFile(s, "ABC","","abc",None) )
        self.assertFalse( hasFile(s, "DEF","","def",None) )
        
        s = ls("/")
        self.assertTrue( hasFile(s, "ABC","","abc",None) )
        self.assertFalse( hasFile(s, "DEF","","def",None) )
        
        s = ls("abc")
        self.assertFalse( hasFile(s, "ABC","","abc",None) )
        self.assertTrue( hasFile(s, "DEF","","def",None) )
        
        s = ls("/abc")
        self.assertFalse( hasFile(s, "ABC","","abc",None) )
        self.assertTrue( hasFile(s, "DEF","","def",None) )
 
        s = ls("abc/def")
        #3: header, . , ..
        self.assertTrue( len(s.strip().split("\n") ) == 3 )
        
        s = ls("/abc/def")
        self.assertTrue( len(s.strip().split("\n") ) == 3 )
        
    def test_mkdir9(self):
        
        go("create",48,"cp","Makefile","MAKE.TXT")
        go("cp","vbr.s","vbr.s")
        go("mkdir","abc")
        go("cp","bootblock.py","abc/xyz.text")
        
        s = ls("/")
        self.assertTrue( hasFile( s, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertTrue( hasFile( s, "ABC", "", "abc", None ) )
        self.assertFalse( hasFile( s, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
        
        s = ls("/abc")
        self.assertFalse( hasFile( s, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertFalse( hasFile( s, "ABC", "", "abc", None ) )
        self.assertTrue( hasFile( s, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
       
        self.assertTrue( readFile("bootblock.py") in cat("/abc/xyz.text"))

    def test_mkdir10(self):
        
        go("create",48,"cp","Makefile","MAKE.TXT")
        go("cp","vbr.s","vbr.s")
        go("mkdir","abc def")
        go("cp","bootblock.py","abc def/xyz.text")
        go("mkdir","abc def/ghi jkl")
        go("cp","bootblock.s","abc def/ghi jkl/qrs.text")

        s = ls("/")
        self.assertTrue( hasFile( s, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertTrue( hasFile( s, "ABCDEF~1", "", "abc def", None ) )
        self.assertFalse( hasFile( s, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
        self.assertFalse( hasFile( s, "GHIJKL~1", "", "ghi jkl", None ) )
        self.assertFalse( hasFile( s, "QRS~1", "TEX", "qrs.text", None ) )
        
        s = ls("/abc def")
        self.assertFalse( hasFile( s, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertFalse( hasFile( s, "ABCDEF~1", "", "abc def", None ) )
        self.assertTrue( hasFile( s, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
        self.assertTrue( hasFile( s, "GHIJKL~1", "", "ghi jkl", None ) )
        self.assertFalse( hasFile( s, "QRS~1", "TEX", "qrs.text", None ) )
        
        s = ls("/abc def/ghi jkl")
        self.assertFalse( hasFile( s, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertFalse( hasFile( s, "ABCDEF~1", "", "abc def", None ) )
        self.assertFalse( hasFile( s, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
        self.assertFalse( hasFile( s, "GHIJKL~1", "", "ghi jkl", None ) )
        self.assertTrue( hasFile( s, "QRS~1", "TEX", "qrs.text", None ) )
        
        self.assertTrue( readFile("bootblock.s") in cat("/abc def/ghi jkl/qrs.text"))
        
        
    def test_rm(self):
        
        go("create",48,"cp","Makefile","MAKE.TXT")
        go("cp","vbr.s","vbr.s")
        go("mkdir","abc def")
        go("cp","bootblock.py","abc def/xyz.text")
        go("mkdir","abc def/ghi jkl")
        go("cp","bootblock.s","abc def/ghi jkl/qrs.text")

        s = ls("/")
        self.assertTrue( hasFile( s, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertTrue( hasFile( s, "ABCDEF~1", "", "abc def", None ) )
        self.assertFalse( hasFile( s, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
        self.assertFalse( hasFile( s, "GHIJKL~1", "", "ghi jkl", None ) )
        self.assertFalse( hasFile( s, "QRS~1", "TEX", "qrs.text", None ) )
        
        s = ls("/abc def")
        self.assertFalse( hasFile( s, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertFalse( hasFile( s, "ABCDEF~1", "", "abc def", None ) )
        self.assertTrue( hasFile( s, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
        self.assertTrue( hasFile( s, "GHIJKL~1", "", "ghi jkl", None ) )
        self.assertFalse( hasFile( s, "QRS~1", "TEX", "qrs.text", None ) )
        
        s = ls("/abc def/ghi jkl")
        self.assertFalse( hasFile( s, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertFalse( hasFile( s, "ABCDEF~1", "", "abc def", None ) )
        self.assertFalse( hasFile( s, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
        self.assertFalse( hasFile( s, "GHIJKL~1", "", "ghi jkl", None ) )
        self.assertTrue( hasFile( s, "QRS~1", "TEX", "qrs.text", None ) )
        
        self.assertTrue( readFile("bootblock.s") in cat("/abc def/ghi jkl/qrs.text"))
        self.assertTrue( readFile("bootblock.s") in cat("/abc def/ghi jkl/QRS~1.TEX"))
                
        go("rm","/abc def/ghi jkl/qrs.text" )
        s3 = ls("/abc def/ghi jkl")
        s1 = ls("/")
        s2 = ls("/abc def")
        self.assertTrue(  hasFile( s1, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertTrue(  hasFile( s1, "ABCDEF~1", "", "abc def", None ) )
        self.assertTrue(  hasFile( s2, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
        self.assertTrue(  hasFile( s2, "GHIJKL~1", "", "ghi jkl", None ) )
        self.assertFalse( hasFile( s3, "QRS~1", "TEX", "qrs.text", None ) )
        
        go("rm","/abc def/ghi jkl")
        s1 = ls("/")
        s2 = ls("/abc def")
        self.assertTrue(  hasFile( s1, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertTrue(  hasFile( s1, "ABCDEF~1", "", "abc def", None ) )
        self.assertTrue(  hasFile( s2, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
        self.assertFalse( hasFile( s2, "GHIJKL~1", "", "ghi jkl", None ) )
        
        go("rm", "/abc def/xyz.text")
        s1 = ls("/")
        s2 = ls("/abc def")
        self.assertTrue(  hasFile( s1, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertTrue(  hasFile( s1, "ABCDEF~1", "", "abc def", None ) )
        self.assertFalse( hasFile( s2, "XYZ~1","TEX", "xyz.text", "bootblock.py" ) )
        self.assertFalse( hasFile( s2, "GHIJKL~1", "", "ghi jkl", None ) )
        
        go("rm","/abc def")
        s1 = ls("/")
        self.assertTrue(  hasFile( s1, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertFalse( hasFile( s1, "ABCDEF~1", "", "abc def", None ) )
        
        go("rm", "/MAKE.TXT")
        s1 = ls("/")
        self.assertFalse( hasFile( s1, "MAKE","TXT","MAKE.TXT", "Makefile" ) )
        self.assertFalse( hasFile( s1, "ABCDEF~1", "", "abc def", None ) )
        
