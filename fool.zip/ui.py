
import fool
import Disk
from utils import log
from fool import FileException

def usage():
    print("fool: A FAT disk tool");
    print("2022 SSU ETEC 3701");
    print("Usage: fool disk.img [options] {commands}");
    print("Options:")
    print("--verbose                      Be verbose")
    print("--help                         Show usage")
    print("Commands consist of one or more of these:");
    print("create {size in MB}            Create image file");
    print("ls {path}                      List directory");
    print("cat {path}                     Display contents of file");
    print("mkdir {path}                   Create directory");
    print("stat {path}                    Get info about file");
    print("cp {path1} {path2}             Copy local file path1 to image as path2");
    print("rm {path}                      Remove (delete) file");
    print("dumpsector {num}               Dump contents of sector");
    print("dumpcluster {num}              Dump contents of cluster");
    print("dumpmbr                        Dump contents of MBR");
    print("dumpvbr                        Dump contents of VBR");
    print("dumpfat {first} {last}         Dump contents of FAT entries first...last");



def go(args):
    global diskfile

    print(args)

    if len(args) == 0:
        usage();
        return;

    diskfilename = args[0];

    disk = Disk.Disk(diskfilename)

    try:

        i=1
        while(i < len(args)):
            cmd = args[i];
            i+=1

            log("===========================================================")
            log("===========================================================")
            log(cmd)
            log("-----------------------------------------------------------")
            log("-----------------------------------------------------------")

            if cmd == "--help":
                usage()
                return
            elif cmd == "--verbose":
                utils.beVerbose(True)
            elif cmd == "create":
                if(i == len(args)):
                    raise FileException("create requires an argument");
                sz = int(args[i]);
                i+=1
                fool.create(disk, sz)
            elif cmd == "ls":
                if(i == len(args)):
                    path = "/";
                else:
                    path = args[i];
                    i+=1
                fool.ls(disk,path);
            elif cmd == "cat":
                if(i == len(args)):
                    raise FileException("cat requires an argument");
                path = args[i]
                i+=1
                fool.cat(disk,path);
            elif cmd == "mkdir":
                if(i == len(args)):
                    raise FileException("mkdir requires an argument");
                path = args[i]
                i+=1
                fool.mkdir(disk,path);
            elif cmd == "stat":
                if(i == len(args)):
                    raise FileException("stat requires an argument");
                path = args[i]
                i+=1
                fool.stat(disk,path);
            elif cmd == "cp":
                if(i >= len(args) - 1):
                    raise FileException("cp requires two arguments");
                if args[i] == "-c":
                    mustBeContiguous = True
                    i+=1
                else:
                    mustBeContiguous = False
                #we might have adjusted i above, so check again
                if(i >= len(args) - 1):
                    raise FileException("cp requires two arguments");
                localpath = args[i]
                i+=1
                imgpath = args[i]
                i+=1
                fool.cp(disk,localpath, imgpath, mustBeContiguous);
            elif cmd == "rm":
                if(i == len(args)):
                    raise FileException("rm requires an argument");
                path = args[i]
                i+=1
                fool.rm(disk,path);
            elif cmd == "dumpsector":
                if(i == len(args)):
                    raise FileException("dumpsector requires an argument");
                sec = int(args[i],0)
                i+=1
                fool.dumpSector(disk,sec);
            elif cmd == "dumpcluster":
                if(i == len(args)):
                    raise FileException("dumpcluster requires an argument");
                cluster = int(args[i],0)
                i+=1
                fool.dumpCluster(disk,cluster);
            elif cmd == "dumpvbr":
                fool.dumpVBR(disk);
            elif cmd == "dumpmbr":
                fool.dumpMBR(disk)
            elif cmd == "dumpfat":
                if(i >= len(args) - 1):
                    raise FileException("dumpfat requires two arguments");
                first = int(args[i])
                i+=1
                last = int(args[i])
                i+=1
                print("FAT: Total entries=", disk.fat.numEntries);
                print("FAT 1: Sectors ", disk.fat.first_fat_sector , " ... " ,
                    disk.fat.first_fat_sector + disk.vbr.sectors_per_fat_32);
                for j in range(first,last+1):
                    print("{1:6,d}: {0:10d} = 0x{0:08x}  " .format(fat[j],j),end="")
                    print();
                print();
            else:
                print("Bad command:",cmd)
                usage();
                raise FileException("Bad command: "+cmd)
                return;
    finally:
        disk.cleanup()
