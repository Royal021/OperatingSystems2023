
import sys
import array
from utils import log
import utils
import os.path
from FAT import FAT
from VBR import VBR
import InfoSector
from DirEntry import *
from MBR import MBR,GPT

mode="sd"

class Disk:
    
    def __init__(self,filename):
        assert type(filename) == str
        self.filename=filename
        self.mbr_=None
        self.gpt_=None
        self.vbr_=None     
        self.fat_=None   
        self.numDataSectors_=None
        
        if not os.path.exists(self.filename):
            self.fs = open(self.filename,"w+b")
        else:
            self.fs = open(self.filename,"r+b")
        
    @property
    def firstDataSector(self):
        #First sector of first partition on disk
        return self.gpt.gptentries[0].firstSector
        
    @property
    def numDataSectors(self):
        return self.gpt.gptentries[0].lastSector-self.gpt.gptentries[0].firstSector+1
        # ~ if self.numDataSectors_==None:
            # ~ self.fs.seek(0,2)
            # ~ totalSectors = self.fs.tell()//512
            # ~ self.numDataSectors_ = totalSectors - self.firstDataSector
            
        # ~ return self.numDataSectors_
        
    @property
    def mbr(self):
        if not self.mbr_:
            self.mbr_ = MBR(data=self.readAbsoluteSector(0))
        return self.mbr_
    
    @property
    def gpt(self):
        if not self.gpt_:
            self.gpt_ = GPT.readFromDisk(self)
        return self.gpt_
        
    @property
    def vbr(self):
        if not self.vbr_:
            b = self.readAbsoluteSector(self.gpt.firstDataSector)
            self.vbr_ = VBR(sectorData=b,startSector=None,numSectors=None)
        return self.vbr_
        
    @property
    def fat(self):
        if not self.fat_:
            self.fat_ = FAT(self)
        return self.fat_
    
    def flush(self):
        #ensure we re-read these things
        self.gpt_ = None
        self.mbr_ = None
        self.vbr_ = None
        self.fat_ = None
             

    def create(self,sizeBytes):
        #important: Don't read vbr or fat until they're
        #asked for -- so we can get the new data
        #if disk is being initialized
        self.vbr_=None
        self.fat_=None
        self.fs.seek(0)
        self.fs.truncate()
        self.fs.close()
        self.fs = open(self.filename,"r+b")
        self.fs.seek(sizeBytes-1)
        self.fs.write(bytes(1))

    def cleanup(self):
        if self.fs != None:
            if self.fat_:
                self.fat.writeDirty();
            if self.vbr_:
                isec = InfoSector.InfoSector()
                self.writeAbsoluteSector( 
                    self.vbr.first_sector + self.vbr.fsinfo_sector, 
                    isec.toBytes()
                )
                
            self.fs.close()
            self.fs=None

    def readAbsoluteSector(self,sectorNumber):
        self.fs.seek(sectorNumber*512)
        data = self.fs.read(512)
        return data
    
    def readRelativeSector(self,sectorNumber):
        return self.readAbsoluteSector(self.firstDataSector+sectorNumber)
   
    def writeRelativeSector(self,sectorNumber, data):
        return self.writeAbsoluteSector(self.firstDataSector+sectorNumber,data)

    def writeAbsoluteSector(self, secnum, data):
        if type(data) == array.array:
            tmp = data.tobytes()
        elif type(data) == bytes:
            tmp = data
        elif type(data) == bytearray:
            tmp = data
        elif type(data) == list:
            tmp = bytes(data)
        else:
            print(type(data))
            assert 0
         
        self.fs.seek(secnum*512,0)
        if len(data) != 512:
            raise RuntimeError(f"len(data)={len(data)} but should be 512")
        self.fs.write(tmp)
            
    def clusterNumberToSectorNumber(self,clusterNumber):
        assert self.vbr.data_start > 0
        assert self.vbr.sectors_per_cluster > 0
        secnum = self.vbr.data_start + self.vbr.sectors_per_cluster * (clusterNumber - 2);
        return secnum  
              
    def readCluster(self,clusterNumber):
        """Read one cluster"""
        log("readCluster",clusterNumber)
        secnum = self.clusterNumberToSectorNumber(clusterNumber)
        self.fs.seek(secnum*512)
        b=self.fs.read(self.vbr.bytes_per_cluster)
        return b;

    def writeCluster( self, clusterNumber, data):
        log("writeCluster",clusterNumber,"with", "".join( [chr(x) for x in data[:96]] ) )
        if(len(data) != self.vbr.bytes_per_cluster):
            raise Exception("data size != cluster size");
        sz = self.vbr.bytes_per_sector;
        sec = self.vbr.data_start + (clusterNumber - 2) * self.vbr.sectors_per_cluster;
        for i in range(self.vbr.sectors_per_cluster):
            tmp = data[i*sz:i*sz+sz]
            self.writeAbsoluteSector(sec, tmp);
            sec+=1

    def readdir( self, *, directoryName=None, firstCluster=None):
        """Return list of DirEntry objects. Accepts
            either the name of the directory or 
            its first cluster."""
        
        assert directoryName != None or firstCluster != None
        assert directoryName == None or firstCluster == None
        
        log("readdir",directoryName,firstCluster)
        if directoryName != None:
            dirpath = directoryName
            if(dirpath == ""):
                fc = self.vbr.root_cluster;
            else:
                #DirEntry de;
                b,de = self.doStat(dirpath)
                if b == False:
                    raise FileException("Path " + dirpath + " not found");
                if( not de.shortentry.isDirectory):
                    raise FileException("Path " + dirpath + " is not a directory");
                fc = de.firstCluster;
            return self.readdir(firstCluster=fc);
        else:
            log("readdir: First cluster=",firstCluster)
            dirClusterChain = self.fat.getClusterChain(firstCluster);
            dirData = self.readFile(dirClusterChain, 0xffffffff);
            log("dirData=","".join([chr(x) for x in dirData[:128]]))
            idx = 0;
            L = DirEntryList();
            while(True):
                de,idx = DirEntry.make(dirData,idx)
                if(de != None):
                    L.append(de)
                    log("Got dir entry:",de)
                else :
                    break;
            return L



    def readFile( self, clusters, size ):
        """read up to min{ size, data_in_cluster_chain} bytes.
            The clusters of the file are specified in the clusters
            parameter"""
        
        log("readFile: Clusters=",clusters,"size=",size)
        #List<uint> clusters, uint size
        assert self.vbr.sectors_per_cluster != 0
        maxdata = (self.vbr.sectors_per_cluster * 512 * len(clusters))
        if(size < 0 or size > maxdata):
            size = maxdata;
        rv = [0]*size
        amountRead = 0;
        amountRemaining = size;
        ci = 0;
        while(ci < len(clusters) and amountRemaining > 0 ):
            data = self.readCluster(clusters[ci]);
            le = len(data)
            if amountRemaining < le:
                amt = amountRemaining
            else:
                amt = le
            rv[amountRead:amountRead+amt] = data[0:amt]
            amountRead += amt;
            amountRemaining -= amt;
            ci += 1

        return rv


    #if firstCluster is 0, assumes existing file has no clusters.
    #Re-uses as many clusters as possible for the file, then allocates new ones
    #if file size is larger. If file has shrunk, truncate cluster chain.
    #Returns first cluster, or zero if empty file.
    #If data is not a multiple of the cluster size, the file will
    #be padded with arbitrary data.
    def writeFile(self, data,firstCluster,useFirstFreeSpace):
         
        log("writeFile: to cluster",firstCluster,"data=",data[:96])
        #special case: if the file is zero size,
        #free all clusters
        if len(data) == 0:
            if(firstCluster != 0):
                fat.freeChain(firstCluster);
            return 0;
        
        if(firstCluster == 0):
            firstCluster = self.fat.getAnotherCluster(0,useFirstFreeSpace);
            log("got cluster",firstCluster,"to start the file")
            
        start = 0;
        sz = self.vbr.bytes_per_cluster;
        c = firstCluster;
        b = [0]*self.vbr.bytes_per_cluster
        while(start < len(data)):
            dataLeft = len(data) - start;
            if dataLeft >= len(b):
                utils.copyArrayToArray(data, start, b, 0, len(b));
            else:
                utils.copyArrayToArray(data, start, b, 0, dataLeft);
                for i in range(dataLeft,len(b)):
                    b[i] = (65 + (i % 26));   #random padding
            self.writeCluster(c, b);
            start += len(b)
            if start < len(data):
                c = self.fat.getAnotherCluster(c,useFirstFreeSpace);
                log("got another cluster:",c)
            else:
                self.fat.freeAllClustersAfter(c);

        return firstCluster;


    def doStat(self,path):
        assert type(path) == str
        log("doStat(",path,")")
        try:
            path = utils.normalizePath(path);
            log("Normalized path:",path)
            if(path == ""):
                #root directory: Special case
                log("Root")
                dirent = DirEntry();
                dirent.firstCluster = self.vbr.root_cluster;
                dirent.shortentry.attributes = ShortDirEntry.DIRECTORY;
                return True,dirent

            firstCluster = self.vbr.root_cluster;
            components = path.split("/")
            log("doStat: components=",components)
            for i in range(len(components)):
                log("doStat: Processing component",i,"=",components[i])
                dents = self.readdir(firstCluster=firstCluster);
                foundIt = False;
                for j in range(len(dents)):
                    if(dents[j].nameMatches(components[i]) ):
                        log("Found match for",components[i],"in dents[",j,"]=",dents[j])
                        if(i == len(components) - 1) :
                            dirent = dents[j];
                            log("doStat: Last one! Return:",dirent)
                            return True,dirent;
                        else:
                            firstCluster = dents[j].firstCluster;
                            foundIt = True;
                            break;
                if not foundIt:
                    log("doStat: Did not find entry")
                    return False,None
            log("doStat: Did not find entry (2)")
            return False,None
        finally:
            log("doStat: Done")


