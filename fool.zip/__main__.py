import sys
import ui
import unittest
import os
import tracemalloc

if __name__ == "__main__":
    args = sys.argv[1:]
    if len(args)==1 and args[0] == "--test":
        tracemalloc.start()
        unittest.main(module="tests",
            argv=[sys.argv[0]],
            verbosity=2,
            failfast=True,
            defaultTest=None    #"TestCreate.test_create_toosmall"
            )
        #tests.test()
    try:
        ui.go(args)
    except Exception as e:
        print(e)
        raise
        sys.exit(1)
