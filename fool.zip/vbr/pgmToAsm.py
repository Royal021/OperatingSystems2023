import sys

infile = sys.argv[1]
outfile= sys.argv[2]

with open(infile,"rb") as fp:
    fp.readline()
    fp.readline()
    w,h = [int(q) for q in fp.readline().decode().strip().split()]
    fp.readline()
    data = fp.read(w*h)
    assert len(data) == w*h
    
with open(outfile,"w") as fp:
    SIZE=16
    for i in range(0,len(data),SIZE):
        tmp = data[i:i+SIZE]
        tmp = [int(q) for q in tmp]
        tmp = [str(q) for q in tmp]
        tmp = ",".join(tmp)
        print("db",tmp,file=fp)
        
    
