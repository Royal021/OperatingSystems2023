import ctypes
import vbrcode
from utils import copyArrayToArray

class VBR_(ctypes.Structure):
    _pack_=1
    _fields_ = [
        ("jmp",ctypes.c_ubyte*3),
        ("oem",ctypes.c_ubyte*8),
        ("bytes_per_sector", ctypes.c_ushort),
        ("sectors_per_cluster", ctypes.c_ubyte),
        ("reserved_sectors", ctypes.c_ushort), 
        ("num_fats" , ctypes.c_ubyte  ),
        ("num_root_dir_entries" , ctypes.c_ushort     ),
        ("num_sectors_small" , ctypes.c_ushort     ),
        ("id" , ctypes.c_ubyte     ),
        ("sectors_per_fat_12_16" , ctypes.c_ushort     ),
        ("sectors_per_track" , ctypes. c_ushort    ),
        ("num_heads" , ctypes. c_ushort    ),
        ("first_sector" , ctypes.c_uint     ),
        ("num_sectors_big" , ctypes.c_uint     ),
        ("sectors_per_fat_32" , ctypes.c_uint     ),
        ("flags" , ctypes.c_ushort     ),
        ("version" , ctypes.c_ushort     ),
        ("root_cluster" , ctypes.c_uint     ),
        ("fsinfo_sector" , ctypes.c_ushort     ),
        ("backup_boot_sector" , ctypes.c_ushort     ),
        ("reservedField" , ctypes.c_ubyte*12     ),
        ("drive_number" , ctypes.c_ubyte     ),
        ("flags2" , ctypes.c_ubyte     ),
        ("signature" , ctypes.c_ubyte     ),
        ("serial_number" , ctypes.c_uint     ),
        ("label" , ctypes.c_ubyte*11     ),
        ("identifier" , ctypes.c_ubyte*8     ),
        ("code" , ctypes.c_ubyte*420     ),
        ("checksum" , ctypes.c_ushort     )
    ]
    
class VBR:
    #S = struct.Struct( "<3B8BHBHBHHBHHHIIIHHIHH12BBBBI11B8B420BH" )
    
    def __init__(self, *, sectorData, startSector, numSectors):
        """
            To create VBR from existing data (512 bytes): Set
            sectorData to the byte data, set startBytes and sizeBytes to None
            To create a new VBR: set sectorData to None and
            set startBytes to the *byte offset* of the VBR (should be
            a multiple of sector size) and sizeBytes to the size 
            of the partition (should be a multiple of 512)
        """
        assert ctypes.sizeof(VBR_) == 512
        
        assert sectorData != None or startSector != None
        
        if sectorData != None:
            assert startSector==None
            assert numSectors==None
        if startSector != None:
            assert sectorData==None
            assert numSectors != None
        
        if sectorData != None:
            b = sectorData
            if(len(b) != 512):
                raise RuntimeError(f"Buffer is {len(b)} bytes; expected 512")
            self.V = VBR_.from_buffer_copy(b)
        else:
            self.V = VBR_()
            
            #jmp short dest , nop
            self.V.jmp[0] = 0xeb    #jmp
            self.V.jmp[1] = 0x58    #offset
            self.V.jmp[2] = 0x90    #nop
            for i,v in enumerate([ 69, 84, 69, 67, 51, 55, 48, 49 ] ): #ETEC3701
                self.V.oem[i] = v
            self.V.bytes_per_sector = 512
            self.V.sectors_per_cluster = 8    #always 4KB
            #wikipedia says fat32 usually uses 32 
            #man page for vfat says must be >=2, default is 32
            self.V.reserved_sectors = 32  
            self.V.num_fats = 2
            self.V.num_root_dir_entries = 0   #not used on fat32
            self.V.num_sectors_small = 0    #only used if disk size < 32MB
            self.V.id = 0xf8  #media descriptor
            self.V.sectors_per_fat_12_16 = 0    #only used for fat 12 or fat 16
            self.V.sectors_per_track = 32
            self.V.num_heads = 64
            ##self.V.first_sector = startSector
            ##self.V.num_sectors_big = 0

            #fat32
            self.V.sectors_per_fat_32 = 0
            self.V.flags = 0        #should be zero
            self.V.version = 0
            self.V.root_cluster = 2
            self.V.fsinfo_sector = 1    #usually right after vbr: Relative sector number
            for i in range(12):
                self.V.reservedField[i]=0
            self.V.drive_number = 0x80
            self.V.flags2 = 0
            self.V.signature = 0x28     #0x28 or 0x29
            self.V.serial_number = 0x12345678
            for i,v in enumerate([ 77, 79, 79, 67, 79, 87, 49, 50, 51, 52, 53 ]): #MOOCOW12345
                self.V.label[i]=v
                
            for i,v in enumerate([ 70, 65, 84, 51, 50, 32, 32, 32 ]):  #FAT32(sp)(sp)(sp)
                self.V.identifier[i] = v
            for i in range(420):
                self.V.code[i]=0
            self.V.checksum = 0xaa55   #0xaa55
        
            
            self.V.first_sector = startSector
            self.V.backup_boot_sector = startSector+1   #must be within reserved_sectors (vbr_sectors)

            #FIXME: this is more complex than it needs to be...
            self.V.num_sectors_big = (numSectors*512 // self.bytes_per_cluster * self.bytes_per_cluster // 512 )
            if self.V.num_sectors_big == 0:
                raise RuntimeError("Drive is too small")
            #how many clusters does one sector of FAT keep track of?
            clustersPerFatSector = 512//4
            nc = self.V.num_sectors_big // self.sectors_per_cluster
            self.V.sectors_per_fat_32 = nc // clustersPerFatSector 
            if(nc % clustersPerFatSector != 0):
                self.V.sectors_per_fat_32+=1
    
    def write(self,disk):
            
        bb = bytearray(vbrcode.data)
        
        if len(bb) % 512:
            extra = len(bb) % 512
            padding = 512-extra
            bb += bytearray(padding)
            
        #copy code from bootblock to the code field.
        #Skip the 90 bytes of parameter data
        #to avoid the machine code that leads off the vbr on disk
        
        for i in range(90,90+len(self.code)):
            self.code[i-90] = bb[i]

        disk.writeAbsoluteSector( self.V.first_sector, 
                                  self.toBytes())
        
        
        #write the backup boot sector
        disk.writeAbsoluteSector(
            self.backup_boot_sector, 
            self.toBytes());
        
        #write boot block data: sectors 1...n of bb
        secnum = self.V.first_sector+2
        offset = 1024
        while offset < len(bb):
            disk.writeAbsoluteSector(
                secnum,
                bb[offset:offset+512]
            )
            secnum+=1
            offset += 512
        
        disk.flush()
        
        
    @property
    def fat_start(self):
        return self.first_sector + self.reserved_sectors

    @property
    def data_start(self):
        return self.fat_start + self.num_fats * self.sectors_per_fat_32

    @property
    def  bytes_per_cluster(self):
        return (self.sectors_per_cluster * 512)

    @property
    def num_sectors(self):
        if self.num_sectors_small == 0:
            return self.num_sectors_big
        else:
            return self.num_sectors_small

    @property
    def num_data_sectors(self):
        return self.num_sectors - self.reserved_sectors - self.num_fats * self.sectors_per_fat_32

    @property
    def num_clusters(self):
        return self.num_data_sectors // self.sectors_per_cluster 
     
    def toBytes(self):
        p = ctypes.pointer(self.V)
        b = ctypes.string_at(p,512)
        assert len(b) == 512
        return b
         
    def __repr__(self):
        return str(self)
        
    def __str__(self):
        L=[]
        
        def wr(L,cap,b):
            def X(b):
                s=""
                for x in b:
                    s += chr(x)
                L.append(cap+": "+s)
                
            if type(b) == list or type(b) == bytes or type(b) == bytearray:
                X(b)
            elif type(b) == int:
                L.append( cap+": "+str(b)+" = "+hex(b) )
            else:
                p = ctypes.pointer(b)
                X(ctypes.string_at(p,ctypes.sizeof(b)))
                
        wr(L,"OEM", self.oem)
        wr(L,"Bytes per sector", self.bytes_per_sector)
        wr(L,"Sectors per cluster", self.sectors_per_cluster)
        wr(L,"Reserved sectors", self.reserved_sectors)
        wr(L, "Num FATs", self.num_fats)
        wr(L, "Num root directory entries (only for FAT 12/16)", self.num_root_dir_entries)
        wr(L, "Num sectors (only for disks <32MB)", self.num_sectors_small)
        wr(L, "ID", self.id)
        wr(L, "Sectors per FAT (only for FAT 12/16)", self.sectors_per_fat_12_16)
        wr(L, "Sectors per track", self.sectors_per_track)
        wr(L, "Num heads", self.num_heads)
        wr(L, "First sector", self.first_sector)
        wr(L, "Num sectors (only for disks >= 32MB)", self.num_sectors_big)
        wr(L, "Sectors per FAT (only for FAT 32)", self.sectors_per_fat_32)
        wr(L, "Flags", self.flags)
        wr(L, "Version", self.version)
        wr(L, "Root directory cluster (only for FAT 32)", self.root_cluster)
        wr(L, "FS Info sector", self.fsinfo_sector)
        wr(L, "Backup VBR", self.backup_boot_sector)
        wr(L, "Drive number", self.drive_number)
        wr(L, "Flags 2", self.flags2)
        wr(L, "Signature", self.signature)
        wr(L, "Serial number", self.serial_number)
        wr(L, "Label", self.label)
        wr(L, "Identifier", self.identifier)
        wr(L, "Checksum", self.checksum)

        L.append("Computed values:")
        L.append( "Disk size: {} bytes".format(self.num_sectors_big*512))
        wr(L, "FAT start sector", self.fat_start)
        wr(L, "Data start sector", self.data_start)
        wr(L, "Bytes per cluster", self.bytes_per_cluster)
        L.append( "Num data sectors: {} = {} bytes".format(
            self.num_data_sectors,
            self.num_data_sectors*self.bytes_per_sector))
        L.append( "Num data clusters: {} = {} bytes".format(
            self.num_clusters,
            self.num_clusters * self.bytes_per_cluster))
        L.append( "FAT capacity: {} entries".format( self.sectors_per_fat_32 * (512 // 4) ))
        L.append( "Num excess FAT entries: {}".format(self.sectors_per_fat_32 * (512 // 4) - self.num_clusters))
        return "\n".join(L)


    @property
    def jmp(self):
        return self.V.jmp

    @property
    def oem(self):
        return self.V.oem

    @property
    def bytes_per_sector(self):
        return self.V.bytes_per_sector

    @property
    def sectors_per_cluster(self):
        return self.V.sectors_per_cluster

    @property
    def reserved_sectors(self):
        return self.V.reserved_sectors

    @property
    def num_fats(self):
        return self.V.num_fats

    @property
    def num_root_dir_entries(self):
        return self.V.num_root_dir_entries

    @property
    def num_sectors_small(self):
        return self.V.num_sectors_small

    @property
    def id(self):
        return self.V.id

    @property
    def sectors_per_fat_12_16(self):
        return self.V.sectors_per_fat_12_16

    @property
    def sectors_per_track(self):
        return self.V.sectors_per_track

    @property
    def num_heads(self):
        return self.V.num_heads

    @property
    def first_sector(self):
        return self.V.first_sector

    @property
    def num_sectors_big(self):
        return self.V.num_sectors_big

    @property
    def sectors_per_fat_32(self):
        return self.V.sectors_per_fat_32

    @property
    def flags(self):
        return self.V.flags

    @property
    def version(self):
        return self.V.version

    @property
    def root_cluster(self):
        return self.V.root_cluster

    @property
    def fsinfo_sector(self):
        return self.V.fsinfo_sector

    @property
    def backup_boot_sector(self):
        return self.V.backup_boot_sector

    @property
    def reservedField(self):
        return self.V.reservedField

    @property
    def drive_number(self):
        return self.V.drive_number

    @property
    def flags2(self):
        return self.V.flags2

    @property
    def signature(self):
        return self.V.signature

    @property
    def serial_number(self):
        return self.V.serial_number

    @property
    def label(self):
        return self.V.label

    @property
    def identifier(self):
        return self.V.identifier

    @property
    def code(self):
        return self.V.code

    @property
    def checksum(self):
        return self.V.checksum

         
