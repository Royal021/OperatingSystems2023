import array
import utils

class FAT:
    
    EOF_START =  0x0ffffff8
    EOF = 0x0fffffff
    ENTRIES_PER_SECTOR = 512//4
    
    def __init__(self, disk ):
        self.disk = disk

        #we maintain sectors of fat in RAM
        #key = sector number (expressed as offset from fat start)
        #value = 512 bytes (=128 entries) of fat data, as an array
        self.fatdata = {}
        self.dirty = set() #keys are like those in fatdata
        self.first_fat_sector =  self.disk.vbr.fat_start
        self.numEntries = self.disk.vbr.num_clusters
        self.sectors_per_fat = self.disk.vbr.sectors_per_fat_32
        
    def writeDirty(self):
        for s in self.dirty:
            self.disk.writeAbsoluteSector(self.first_fat_sector + s, self.fatdata[s].tobytes())
            self.disk.writeAbsoluteSector(self.first_fat_sector + self.sectors_per_fat + s, self.fatdata[s].tobytes())

    def __getitem__(self,idx):
        v = self.getAndSet(idx,None)
        assert type(v) == int
        return v
        
    def __setitem__(self,idx,value):
        assert type(value) == int
        self.getAndSet(idx,value)
        
    def getAndSet(self,idx,value):
        if(idx >= self.numEntries):
            raise RuntimeError("Attempt to get FAT entry {} but max is {}".format(idx,numEntries))
        sn = (idx // self.ENTRIES_PER_SECTOR)
        if sn not in self.fatdata:
            b = self.disk.readAbsoluteSector(self.first_fat_sector + sn)
            data = array.array("I", [0]*self.ENTRIES_PER_SECTOR )
            for i in range(0,len(b),4):
                v = (b[i] | (b[i + 1] << 8) | (b[i + 2] << 16) | (b[i + 3] << 24))
                data[i // 4] = v
            self.fatdata[sn] = data
        offs = (idx % self.ENTRIES_PER_SECTOR)
        if value == None:
            return self.fatdata[sn][offs]
        else:
            self.fatdata[sn][offs] = value
            self.dirty.add(sn)
             

    def getClusterChain( self, firstCluster ):
        cl = firstCluster
        assert type(cl) == int
        clusters = []
        while cl < self.EOF_START and cl >= 2:
            clusters.append(cl)
            cl = self[cl]
        return clusters

    def freeChain(self,c):
        while(c >= 2 and c < self.EOF_START) :
            n = self[c]
            self[c] = 0
            c = n

    def freeAllClustersAfter(self,c):
        self.freeChain(self[c])

    def allocCluster(self, useFirstFreeSpace):
        c = 0
        if(useFirstFreeSpace):
            for i in range(2,self.numEntries):
                if self[i] == 0:
                    c = i
                    break
        else:
            choices = []
            i=32
            while i < self.numEntries and len(choices) < 8:
                for delta in range(0,257,128):
                    j = i + delta
                    if j < self.numEntries and self[j] == 0:
                        choices.append(j)
                i+=1
            if len(choices) > 0:
                choices = utils.shuffle(choices)
                c = choices[0]
            else:
                c=0

        if( c == 0 ):
            raise RuntimeError("Disk is full")

        self[c] = self.EOF
        return c
    

    def getAnotherCluster(self, c,  useFirstFreeSpace):
        if(c == 0 or self[c] >= self.EOF_START):
            n = self.allocCluster(useFirstFreeSpace)
            if(c != 0):
                self[c] = n
            self[n] = self.EOF 
            return n
        else:
            return self[c]

