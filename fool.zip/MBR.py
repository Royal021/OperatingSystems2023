
import ctypes
import binascii
import mbrcode

#sector 0: MBR, type=0xee, covers whole disk
#sector 1: GPT_ structure
#sector 2...33 inclusive: Partition table
#Data area begins at sector 34
#Should be backup GPT as last sector of disk
#and backup partition table in last 32 sectors prior to that one
    
    
class GUID(ctypes.Structure):
    _pack_=1
    _fields_=[
        ("first", ctypes.c_uint32),
        ("second" , ctypes.c_uint16),
        ("third", ctypes.c_uint16),
        ("fourth", ctypes.c_uint16),
        ("fifth", ctypes.c_ubyte * 6)
    ]
    def __repr__(self):
        return "{:08x}-{:04x}-{:04x}-{:04x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}".format(
            self.first, self.second,self.third,self.fourth,
            self.fifth[0],self.fifth[1],self.fifth[2],
            self.fifth[3],self.fifth[4],self.fifth[5]
        )

   
def __int6(val):
    L=[]
    for i in range(6):
        L.append(val & 0xff)
        val >>= 8
    A=(ctypes.c_ubyte*6)()
    for i,j in enumerate(reversed(L)):
        A[i]=j
    return A
    
EFI_GUID = GUID( first=0xc12a7328, second=0xf81f, third=0x11d2,
                 fourth=0xba4b, fifth=__int6(0x00a0c93ec93b) )
WINDOWS_DATA_GUID = GUID( first=0xebd0a0a2, second=0xb9e5,
    third=0x4433, fourth=0x87c0, fifth=__int6(0x68b6b72699c7) )
    
RANDOM_GUID = GUID(first=0x12345678, second=0xcafe,
    third=0xbeef, fourth=0xabcd, fifth=__int6(0xf00f00feefee) )
 
RANDOM_GUID2 = GUID(first=0x987654321, second=0xfeed,
    third=0xdeed, fourth=0x2468, fifth=__int6(0xb007b007b007) )


#MBR types
TYPE_PROTECTIVE_MBR = 0xee
TYPE_WINDOWS_FAT32LBA = 0x0c

       
def dumpStruct(obj,fields,L,onOneLine,prefix):
    if onOneLine:
        L.append(prefix)
        
    for fieldname,fieldtype in fields:
        attr = obj.__getattribute__(fieldname)
        if fieldtype in [ctypes.c_uint32,ctypes.c_uint64]:
            val="{} (0x{:02x})".format(attr,attr)
        elif fieldtype == GUID:
            val=str(attr)
        else:
            continue
        txt=f"{fieldname}: {val}"
        if onOneLine:
            if len(L[-1]) > 0:
                L[-1] += " "
            L[-1] += txt
        else:
            L.append(f"{prefix}{txt}")
    
    

class MBRPartitionTableEntry(ctypes.Structure):
    _pack_=1
    _fields_=[
        ("flags", ctypes.c_ubyte),     #0x80=used, 0x00=unused
        ("startingCHS", ctypes.c_ubyte*3),
        ("type", ctypes.c_ubyte),
        ("endingCHS", ctypes.c_ubyte*3),
        ("startingSector", ctypes.c_uint32),
        ("numSectors", ctypes.c_uint32)
    ]
    
        
class MBR_(ctypes.Structure):
    _pack_=1
    _fields_=[
        ("code",ctypes.c_ubyte*446),
        ("partitions", MBRPartitionTableEntry*4),
        ("signature", ctypes.c_ubyte*2)     #0x55, 0xaa
    ]
    

class MBR:
    def __init__(self, data):
        if data != None:
            assert len(data) == 512
            self.mbr = MBR_.from_buffer_copy(data)
        else:
            self.mbr = MBR_()
            src = mbrcode.data
            for i in range(len(src)):
                self.mbr.code[i] = src[i]
            self.mbr.signature[0]=0x55
            self.mbr.signature[1]=0xaa
                
    def __repr__(self):
        L=[]
        L.append(f"MBR")
        for i in range(4):
            e = self.mbr.partitions[i]
            dumpStruct(e,MBRPartitionTableEntry._fields_,L,
                onOneLine=True,prefix=f"Partition {i}:")
            
            # ~ L.append(f"Partition {i}: flags: 0x{e.flags:02x} StartCHS: 0x{e.startingCHS:06x} EndCHS: 0x{e.endingCHS:06x}"
                     # ~ f"Type: 0x{e.type:02x} StartSector: {e.startingSector} NumSectors: {e.numSectors}")
        
        L.append(f"Signature: 0x{self.mbr.signature[1]:02x}{self.mbr.signature[0]:02x}")
        
        return "\n".join(L)    
    
    def addPartition(self,index,type,startingSector,numSectors):
        self.mbr.partitions[index]=MBRPartitionTableEntry(
            flags=0x80, 
            type=type,
            startingSector=startingSector,
            numSectors=numSectors)
            
    def write(self,disk):
        disk.writeAbsoluteSector(0,self.tobytes())
        disk.flush()
        
    def tobytes(self):
        return ctypes.string_at( 
            ctypes.byref( self.mbr ), 
            ctypes.sizeof(self.mbr) 
        )
        
#############################################################

        
#GPT header
class GPT_ (ctypes.Structure):
    _pack_=1
    _fields_=[
        ("signature", ctypes.c_ubyte*8),     #EFI PART
        ("revision", ctypes.c_uint32),      #0x01000000
        ("headerSize", ctypes.c_uint32),    #92
        ("headerCRC", ctypes.c_uint32),
        ("zero", ctypes.c_uint32),
        ("header0Sector", ctypes.c_uint64), #this sector. Usually 1.
        ("header1Sector", ctypes.c_uint64),
        ("firstDataSector", ctypes.c_uint64),
        ("lastDataSector", ctypes.c_uint64),
        ("guid", GUID),
        ("tableSector", ctypes.c_uint64),   #2
        ("numEntries", ctypes.c_uint32),
        ("entrySize", ctypes.c_uint32),     #128
        ("tableCRC", ctypes.c_uint32),
        ("reserved", ctypes.c_byte*420)
    ]
 
      
class GPTPartitionTableEntry(ctypes.Structure):
    _pack_=1
    _fields_=[
        ("partitionType", GUID ),
        ("ownGUID", GUID),
        ("firstSector", ctypes.c_uint64),
        ("lastSector", ctypes.c_uint64),
        ("attributes", ctypes.c_uint64),
        ("name", ctypes.c_uint16 * 36 )
    ]
  
    
def toLE16(data):
    assert len(data) <= 36
    while len(data) < 36:
        data = data+" "
    return (ctypes.c_ushort*36).from_buffer_copy(data.encode("utf_16_le"))

    
class GPT:
    
    @staticmethod
    def readFromDisk(disk):
        b = bytearray()
        for i in range(33):
            b += disk.readAbsoluteSector(i+1) 
        return GPT(data=b)
        
    def __init__(self,data=None,diskSizeSectors=None):
        #size = size of entire disk, including MBR and GPT
        if data != None:
            assert diskSizeSectors==None
            assert len(data) == 33*512, f"data has wrong size: expected {33*512} bytes but got {len(data)} bytes"
            self.gpt = GPT_.from_buffer_copy(data[0:512])
            self.gptentries = (GPTPartitionTableEntry*128).from_buffer_copy(data[512:])
        else:
            assert diskSizeSectors != None
            self.gpt = GPT_(
                revision = 0x01000000,
                headerSize=92,
                headerCRC=0,
                header0Sector=1,
                header1Sector=diskSizeSectors-1,
                firstDataSector=34,
                lastDataSector=diskSizeSectors-34-34,
                guid=RANDOM_GUID,
                tableSector=2,
                numEntries=0,
                entrySize=128,
                tableCRC=0
            )
            
            for i,c in enumerate(b"EFI PART"):
                self.gpt.signature[i]=c
            
            self.updateCRC()
    
            self.gptentries = (GPTPartitionTableEntry*128)()
            
    @property
    def firstDataSector(self):
        return self.gpt.firstDataSector
        
    @property
    def numDataSectors(self):
        return self.gpt.lastDataSector-self.gpt.firstDataSector+1
        
    def tobytes(self):
        return ctypes.string_at( 
            ctypes.byref( self.gpt ), 
            ctypes.sizeof(self.gpt) 
        ) + ctypes.string_at(
            ctypes.byref( self.gptentries ),
            ctypes.sizeof(self.gptentries)
        )
        
    def write(self,disk):
        b = self.tobytes()
        j=1
        for i in range(0,len(b),512):
            disk.writeAbsoluteSector(j,b[i:i+512])
            j+=1
        disk.flush()
        
    def updateCRC(self):
        self.gpt.headerCRC=0
        crc = binascii.crc32( 
            ctypes.string_at(ctypes.byref(self.gpt)),
            ctypes.sizeof(self.gpt) )
        self.gpt.headerCRC=crc
            
    def addPartition(self,numSectors,name):
         
        i = self.gpt.numEntries
        
        fs=self.gpt.firstDataSector if i==0 else self.gptentries[i-1].lastDataSector+1
        ls=fs+numSectors-1
        
        self.gptentries[i] = GPTPartitionTableEntry(
            partitionType=WINDOWS_DATA_GUID,
            ownGUID=RANDOM_GUID2,
            firstSector=fs,
            lastSector=ls,
            attributes=2,  #2=bios bootable
            name=toLE16(name)
        )
        self.gpt.numEntries=i+1
        self.updateCRC()
        
        
    def __repr__(self):
        L=["GPT:"]
        val=[]
        for i in range(8):
            val.append(chr(self.gpt.signature[i]))
        val="".join(val)
        L.append(f"    signature: {val}")
        dumpStruct(self.gpt,GPT_._fields_,L,onOneLine=False,prefix="    ")

        L.append("Partitions:")
        for i in range(self.gpt.numEntries):
            e = self.gptentries[i]
            dumpStruct(e,GPTPartitionTableEntry._fields_,L,onOneLine=True,prefix="    ")
            val=""
            for i in range(len(e.name)):
                c=chr(e.name[i])
                val += c
            L[-1] += (f" name: {val}")
        return "\n".join(L)
