import re
import random
import sys

verbose=False

def beVerbose(flag):
    global verbose
    verbose=flag
    print("SET VERBOSE",flag)

def copyArrayToArray( src, srcidx, dst, dstidx, count):
    tmp = src[srcidx:srcidx+count]
    dst[dstidx:dstidx+len(tmp)] = tmp


def log(*args):
    if not verbose:
        return
    tb = traceback.extract_stack()
    T=tb[-2]
    tmp = [str(q) for q in args]

    x = "{} {} {}".format(T[0].split("/")[-1], T[2], T[1] )

    print("LOG: {:30} {}".format( x,
        " ".join(tmp) )) #,file=sys.stderr)
    sys.stdout.flush()

slashrex = re.compile(r"/{2,}")
def normalizePath(p):
    assert type(p) == str
    p = p.replace("\\", "/");
    p = slashrex.sub("/",p)
    if(p.startswith("/")):
        p = p[1:]
    return p;


def stringFromBytes(bp, sixteenbit):
    if(sixteenbit):
        count = len(bp)
        for i in range(0,len(bp),2):
            if(bp[i] == 0 and bp[i + 1] == 0):
                count = i
                break
        return bp[0:count].decode("utf-16")
    else:
        count = len(bp)
        for i in range(len(bp)):
            if(bp[i] == 0):
                count = i
                break
        return bp[0:count].decode("ascii")



def outputData(b, bytesPerLine):
    for i in range(0,len(b),bytesPerLine):
        print("%4d | " % i, end="")
        for j in range(bytesPerLine):
            print("%02x " % b[i+j],end="")
        print("| ",end="")
        for j in range(bytesPerLine):
            if(b[i + j] >= 32 and b[i + j] < 127):
                print( chr(b[i + j]),end="" )
            else:
                print(".",end="")
        print();

def dirname(path):
    path = normalizePath(path);
    idx = path.rfind('/');
    if(idx == -1):
        return "";
    else:
        return path[0:idx]

def filename(path):
    path = normalizePath(path);
    idx = path.rfind('/');
    if(idx == -1):
        return path;
    else:
        return path[idx + 1:]



__randSeed = 42

def randrange(min, max):
    global __randSeed
    __randSeed ^= (__randSeed<<13)
    __randSeed ^= (__randSeed>>17)
    __randSeed ^= (__randSeed<<15)
    pct = (__randSeed & 0x7fffffff)/(0x7fffffff)
    v = int(min + pct * (max - min))
    if(v < min):
        v = min
    elif(v >= max):
        v = max-1
    return v

def shuffle(L1):
    L=L1[:]
    for i in range(len(L)):
        j = randrange(0, len(L))
        tmp = L[i]
        L[i] = L[j]
        L[j] = tmp
    return L

def bytesFromString(expectedSizeInBytes, s, sixteenbit):
    sdata = []
    if(sixteenbit):
        sdata = s.encode("utf16_le")
    else:
        sdata = s.encode("ascii")
    if len(sdata) != expectedSizeInBytes:
        raise RuntimeError("String size mismatch")
    return array.array("B",sdata)

def readIntArrayFromSector(fs, sector, numElements):
    assert numElements == 512//4
    fs.seek(sector*512, 0)
    ba = fs.read(512)
    ia = array.array(numElements)
    ia.frombytes(ba)
    return ia
