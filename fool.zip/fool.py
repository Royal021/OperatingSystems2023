﻿import array
import ctypes
import datetime
import time
import os
import sys
import utils
import VBR
from DirEntry import *
from utils import *
import MBR

class FileException(RuntimeError):
    def __init__(self,msg=""):
        super().__init__(msg)
        self.message=msg
    
def updateDirEntryForFile(disk,path,newdata):
    #pde = parent dir entry
    head = dirname(path);
    found,pde = disk.doStat(head)
    if not found:
        raise FileException("Not found");
    
    tail = filename(path);
    dents = disk.readdir(directoryName=head);
    for i in range(len(dents)):
        if(dents[i].nameMatches(tail)):
            dents[i] = newdata;
            disk.writeFile(dents.toBytes(disk.vbr.bytes_per_cluster), pde.firstCluster, False);
            return;
            
    if head == "":
        par = "root directory"
    else:
        par = "directory "+head
        
    raise RuntimeError("Could not find information about file "+tail+" in " + par )

   

def mkdir( disk, path):
    log("mkdir",path)
    
    found, de = disk.doStat(path)
    if found:
        raise FileException("File exists");

    head = dirname(path);
    tail = filename(path);

    #pde = parent dir entry
    found, pde = disk.doStat(head)
    if not found:
        raise FileException("Not found");

    L = disk.readdir(directoryName=head);

    #write dummy data to allocate a cluster
    cl = disk.writeFile(bytes(disk.vbr.bytes_per_cluster), 0, False);
    de = DirEntry(tail, ShortDirEntry.DIRECTORY, L);
    de.firstCluster = cl;

    log("mkdir: Allocated cluster",cl,"for",path)
    
    #now rewrite with the data we really want

    de_dot = ShortDirEntry(".", ShortDirEntry.DIRECTORY);
    de_dot.firstCluster = cl;
    de_dotdot = ShortDirEntry("..", ShortDirEntry.DIRECTORY);
    if(pde.isRoot ):
        de_dotdot.firstCluster = 0;     #the root directory
    else :
        de_dotdot.firstCluster = pde.firstCluster;

    B = de_dot.toBytes()
    B += de_dotdot.toBytes()
    if len(B) % disk.vbr.bytes_per_cluster:
        padding = disk.vbr.bytes_per_cluster - (len(B) % disk.vbr.bytes_per_cluster)
        B += bytes(padding)
        
    #rewrite the file with the correct data
    disk.writeFile(B, cl, False );

    L.append(de);
    disk.writeFile(L.toBytes(disk.vbr.bytes_per_cluster), pde.firstCluster, False);


def rm(disk, path):
    found,de = disk.doStat(path)
    if not found:
        raise FileException("No such file " + path);

    if(de.shortentry.name == "." or de.shortentry.name == ".." ):
        raise FileException("Cannot delete special file "+de.shortentry.name);

    if(de.shortentry.isDirectory):
        L = disk.readdir(firstCluster=de.firstCluster);
        if(len(L) != 2):
            raise FileException("Cannot remove non-empty directory");

    if( de.firstCluster != 0 ):
        disk.fat.freeChain(de.firstCluster);

    log("Marking direntry as deleted:",de)
    de.markAsDeleted();

    found,pde = disk.doStat(dirname(path))
    
    if not found:
        raise Exception();
    
    log("updating direntry for path",path,de)
    updateDirEntryForFile( disk, path , de);


        
def stat(fs, path):
    found,de = disk.doStat(path)
    if not found:
        raise FileException("Bad path");
    if(de == None):
        raise FileException("Cannot stat root directory");
    print("Short name: " + de.shortentry.name);
    print("Long name: " + de.longname);
    
    print("Attributes:",de.shortentry.attributes ," (",end="")
    print(" ReadOnly=" , (0!=(de.shortentry.attributes & ShortDirEntry.READONLY)),end="")
    print(" Hidden=" , (0!=(de.shortentry.attributes & ShortDirEntry.HIDDEN)),end="")
    print(" System=" , (0!=(de.shortentry.attributes & ShortDirEntry.SYSTEM)),end="")
    print(" Volume=" , (0!=(de.shortentry.attributes & ShortDirEntry.VOLUME)),end="")
    print(" Directory=" , (0!=(de.shortentry.attributes & ShortDirEntry.DIRECTORY)),end="")
    print(" Archive=" , (0!=(de.shortentry.attributes & ShortDirEntry.ARCHIVE)),end="")
    print(" )");
    print("Created: " , de.shortentry.created);
    print("Modified: " , de.shortentry.lastModified);
    print("Accessed: " , de.shortentry.lastAccessed);
    print("First cluster: " , de.shortentry.firstCluster);
    print("Size: " , de.shortentry.size);
    print("Clusters: ",end="");
    for c in  disk.fat.getClusterChain(de.shortentry.firstCluster):
        print(c,end=" ");
    print();

def ls(disk, path):
    log("Doing ls of",path)
    print()
    L = disk.readdir(directoryName=path);
    print(DirEntry.getHeader());
    for de in L:
        print(de);

def cat(disk, path):
    found,dirent = disk.doStat(path)
    if not found:
        raise FileException("No such file");
    if(dirent == None or not dirent.shortentry.isFile):
        raise FileException("Cannot cat a non-file");
    cl = disk.fat.getClusterChain(dirent.shortentry.firstCluster);
    b = disk.readFile(cl,dirent.shortentry.size);
    for bb in b:
        if( (bb >= 32 and bb <= 126) or bb == 10 or bb == 13 or bb == 9 ):  #9=\t
            sys.stdout.write( chr(bb) )
        else:
            sys.stdout.write( "<%02x>" % bb )
    sys.stdout.write("\n")
    
def cp( disk, src, dst, mustBeContiguous):
    log("cp",src,"   TO    ",dst)
    found,_ = disk.doStat(dst)
    if found:
        raise FileException("Destination " + dst + " exists");
    head = dirname(dst);
    tail = filename(dst);
    with open(src,"rb") as xp:
        data = xp.read()
        
    if (len(disk.readdir(firstCluster=disk.vbr.root_cluster)) == 0
        or
        mustBeContiguous
    ):
        thisIsFirstFile = True
    else:
        thisIsFirstFile = False
    log("cp: writing file")
    cl = disk.writeFile(data,0,thisIsFirstFile);
    log("cp: created file at cluster",cl)
    entries = disk.readdir(directoryName=head);
    de = DirEntry(tail, 0, entries);
    de.firstCluster = cl;
    de.shortentry.size = len(data);
    entries.append(de);
    found,pde = disk.doStat(head)
    assert found
    disk.writeFile(entries.toBytes(disk.vbr.bytes_per_cluster), pde.firstCluster, False);


def create(disk,sizeMB):
    if sizeMB < 33:
        raise FileException("Size must be at least 33MB");
    sizeBytes = sizeMB * 1024 * 1024;
    disk.create(sizeBytes)
    numSectors = sizeBytes//512
    
    disk.flush()
    
    mbr = MBR.MBR(data=None)

    mbr.addPartition( 0, MBR.TYPE_PROTECTIVE_MBR,
        1, numSectors-1 )
    mbr.write(disk)
    
    
    gpt = MBR.GPT(data=None,diskSizeSectors=numSectors)
    gpt.addPartition( gpt.numDataSectors, "C: drive" )
    gpt.write(disk)
        
    vbr = VBR.VBR( 
        sectorData=None, 
        startSector=gpt.gptentries[0].firstSector,
        numSectors=gpt.numDataSectors)
    vbr.write(disk)
    
    #create fat
    
    zeros = bytearray(512)
    
    #first sector of FAT has entries 0 and 1 marked as used.
    #entry 2 (root directory) is set to EOF
    firstone = bytearray(512)
    for k in range(3):
        firstone[4*k] = 0xff;
        firstone[4*k+1] = 0xff;
        firstone[4*k+2] = 0xff;
        firstone[4*k+3] = 0x0f;
        
    s = vbr.fat_start;
    for j in range(vbr.num_fats):
        for i in range(vbr.sectors_per_fat_32):
            if(i == 0):
                disk.writeAbsoluteSector(s,firstone);
            else:
                disk.writeAbsoluteSector(s,zeros);
            s+=1

def dumpSector(disk,sec):
    b = disk.readAbsoluteSector(sec)
    print("Sector ", sec);
    utils.outputData(b,16);

def dumpCluster(disk,cl):
    b = disk.readCluster(cl)
    sec = disk.clusterNumberToSectorNumber(cl)
    print("Cluster ", cl,"(sectors",sec,"...",sec+disk.vbr.sectors_per_cluster-1,")");
    utils.outputData(b,16);

def dumpVBR(disk):
    v = disk.vbr
    print(str(v))

def dumpMBR(disk):
    print(str(disk.mbr))
    print(str(disk.gpt))

     
if __name__ == "__main__":
    import ui
    import sys
    ui.go(sys.argv[1:])
