import pprint
import sys

with open(sys.argv[1],"rb") as fp:
    data = fp.read()
    
with open(sys.argv[2],"w") as fp:
    print("data= (",file=fp)
    for i in range(0,len(data),16):
        for by in data[i:i+16]:
            print("0x{:02x},".format(by),file=fp,end="")
        print(" # ","{:4d}".format(i),":",file=fp,end=" ")
        for by in data[i:i+16]:
            if by >= 32 and by <= 126:
                c=chr(by)
            else:
                c="."
            print(c,end="",file=fp)
        print("",file=fp)
    print(")",file=fp)
