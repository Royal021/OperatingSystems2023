import struct
import array
import datetime
import os
import time

class DirEntry:
    
        
    @property 
    def firstCluster(self):
        return self.shortentry.firstCluster
        
    @firstCluster.setter
    def firstCluster(self,val):
        self.shortentry.firstCluster = val
        
    @staticmethod
    def shortNameExists(L,sn):
        #L = List of DirEntry
        for de in L:
            if de.shortentry.name == sn:
                return True
        return False

    def __init__(self, *args):
        self.isRoot = True
        
        #list of LFNEntry's
        #stored in order they appear on the disk, so first 
        #characters of filename are in last lfn entry
        self.lfn=[]
        
        if len(args) == 0:
            self.shortentry = ShortDirEntry()
        elif len(args) == 3:
            name, attr, existingEntries = args

            if name == "":
                raise RuntimeError("Bad name: Cannot be empty");

            #if the name matches any existing one, flag an error
            for d in existingEntries:
                if(d.nameMatches(name)):
                    raise RuntimeError("Filename already exists");

            #if the original name is a legal short name,
            #don't create any lfn's
            onlyshort = ShortDirEntry.isLegal(name);
            if onlyshort:
                self.shortentry = ShortDirEntry(name, attr)
                return

            #if the original name uppercased is a legal short name,
            #use that as the short name
            if ShortDirEntry.isLegal(name.upper()):
                self.shortentry = ShortDirEntry(name.upper(), attr)
            else:
                tmp=""
                for c in name.upper():
                    if(c == ' '):
                        pass
                    elif not ShortDirEntry.isLegal(c):
                        tmp += "~"
                    else:
                        tmp += c

                if tmp == "":
                    tmp = "~"
                
                parts = tmp.split(".")
                pre = parts[0]
                ext=""
                if len(parts) == 1:
                    ext = "";
                else:
                    ext = parts[-1]
                    
                if len(ext) > 3:
                    ext = ext[0:3]
                    
                ok=False
                for i in range(1,99999):
                    suffix = "~" + str(i)
                    keep = 8 - len(suffix)
                    basen = ""
                    if keep >= len(pre):
                        basen = pre + suffix
                    else:
                        basen = pre[:keep]+suffix
                    proposed = basen;
                    if len(ext) > 0:
                        proposed += "." + ext
                    if not self.shortNameExists(existingEntries, proposed):
                        self.shortentry = ShortDirEntry(proposed, attr)
                        ok = True
                        break
                if not ok:
                    raise RuntimeError("Cannot make short name")
            
            self.lfn = LFNEntry.makeEntries(name, self.shortentry.name)
        elif len(args) == 2:
            b, idxRef = args
            assert type(idxRef) == list
            idx = idxRef[0]
            try:
                while True:
                    if  idx >= len(b):
                        raise RuntimeError("Early end of directory data");
                    
                    if(b[idx] == 0xe5):
                        #deleted
                        idx += 32;
                        continue
                    
                    attr = b[idx + 11];
                    if attr == 0xf:
                        #this is a long filename
                        tmp = LFNEntry(b, idx)
                        idx += 32;
                        if not tmp.deleted:
                            #lfn deleted flag: When does this ever get used?
                            self.lfn.append(tmp)
                    else:
                        self.shortentry = ShortDirEntry(b, idx)
                        #print(idx,"->",self.shortentry)
                        idx += 32
                        return 
            finally:
                idxRef[0] = idx
        else:
            assert 0
        
        
        
    #pull the first direntry from the byte array b. Return the dir entry
    #as well as the first ununsed byte's index
    @staticmethod
    def make(b, idx):
        while idx < len(b):
            if b[idx] == 0:
                return None,idx
            elif b[idx] == 0xe5:  
                #deleted
                idx += 32       #size of dir entry
            else:
                idxRef = [idx]
                de = DirEntry(b,idxRef)
                idx = idxRef[0]
                return de,idx
                
        return None,idx
     
    @property
    def longname(self):
        if len(self.lfn) == 0:
            return self.shortentry.name
        else:
            L = []
            for q in reversed(self.lfn):
                L.append(str(q))
            return "".join(L)

    @staticmethod
    def getHeader():
        return ShortDirEntry.getHeader() + " " + "Long name"
    
    def __repr__(self):
        return str(self)
        
    def __str__(self):
        return str(self.shortentry) + "  " + self.longname;

    def nameMatches(self,s):
        s = s.upper()
        if self.shortentry.name == s:
            return True;
        if  self.longname.upper() == s:
            return True;
        return False;

    def toBytes(self):
        rv=[]
        for l in self.lfn:
            rv += l.toBytes()
        rv += self.shortentry.toBytes()
        return rv

    def markAsDeleted(self):
        for le in self.lfn:
            le.markAsDeleted()
        self.shortentry.markAsDeleted()



class DirEntryList:
    def __init__(self):
        self.dents=[]
        
    def append(self,de):
        assert type(de) == DirEntry
        self.dents.append(de)

    def __iter__(self):
        return self.dents.__iter__()

    def __len__(self):
        return len(self.dents)
        
    def __getitem__(self,idx):
        return self.dents[idx]
    def __setitem__(self,idx,value):
        self.dents[idx]=value
        
    def toBytes(self,cluster_size):
        L = []
        for de in self.dents:
            L += de.toBytes()
        while len(L) % cluster_size != 0 :
            L.append(0)
        
        return array.array("B", L )




class ShortDirEntry:
    READONLY = 1
    HIDDEN = 2
    SYSTEM=4
    VOLUME=8
    DIRECTORY=16
    ARCHIVE=32
    LFN = 15

    #legal chars:
    #capital letters, numbers, `~!@#$%^&'()-_{}
    #LFN's also allow +=[],.  and lowercase
    legal = "ABCDEFGHIJKLMNOPQRSTUVWXYZ12345678901`~!@#$%^&()-_{}'."

    S = struct.Struct( "11BBBBHHHHHHHI" )
    
    def __init__(self, *args):
        self.nameRaw = [0]*11
        self.attributes = 0 #byte
        self.reserved=0     #byte
        self.creationTimeSecondsTenths = 0  #byte 0...199: when divided by two, we get the tenths
        self.creationTimeRaw = 0    #ushort HHHH HMMM MMMS SSSS seconds needs to be mult by 2 and added to prev field
        self.creationDateRaw=0      #ushort #YYYY YYYM MMMD DDDD
        self.lastAccessDateRaw=0    #ushort
        self.clusterHigh=0          #ushort
        self.lastModifiedTimeRaw=0  #ushort
        self.lastModifiedDateRaw=0  #ushort
        self.clusterLow=0           #ushort
        self.size=0                 #uint



        if len(args) == 0:
            pass
        elif len(args) == 2 and type(args[0]) == str:
            nm,attr = args
            self.name = nm        
            self.attributes = attr
            self.reserved = 0
            now = datetime.datetime.now()
            fakeDate = os.getenv("FOOL_NOW",None)
            if fakeDate != None:
                now = time.strptime(fakeDate, "%Y-%b-%d %H:%M:%S")
                print("NOTE: Using fake date")
            self.created = now
            self.lastAccessed = now
            self.lastModified = now
        elif len(args) == 2:
            b,idx = args
            self.nameRaw = array.array("B",b[idx:idx+11])
            idx += 11
            self.attributes = b[idx]
            idx+=1
            self.reserved = b[idx]
            idx+=1
            self.creationTimeSecondsTenths = b[idx]
            idx+=1
            self.creationTimeRaw = (b[idx] | (b[idx + 1] << 8)) 
            idx += 2
            self.creationDateRaw = (b[idx] | (b[idx + 1] << 8)) 
            idx += 2
            self.lastAccessDateRaw = (b[idx] | (b[idx + 1] << 8)) 
            idx += 2
            self.clusterHigh = (b[idx] | (b[idx + 1] << 8)) 
            idx += 2
            self.lastModifiedTimeRaw = (b[idx] | (b[idx + 1] << 8)) 
            idx += 2
            self.lastModifiedDateRaw = (b[idx] | (b[idx + 1] << 8)) 
            idx += 2
            self.clusterLow = (b[idx] | (b[idx + 1] << 8)) 
            idx += 2
            self.size = (b[idx] | (b[idx + 1] << 8) | (b[idx + 2] << 16) | (b[idx + 3] << 24))

    @staticmethod
    def isLegal(value):
    
        #special case
        if(value == "." or value == ".."):
            return True

        if len(value) == 1:
            return value[0] in ShortDirEntry.legal
        else:
            
            if len(value) == 0:
                return False
                
            #capital letters, numbers, `~!@#$%^&'()-_{}
            for c in value:
                if c not in ShortDirEntry.legal:
                    return False
                    
            b=""
            e=""
            lst = value.split(".")
            if len(lst) > 2 or len(lst) < 1:
                return False
                
            b = lst[0]
            if len(lst) > 1:
                e=lst[1]
            
            if len(b) < 1 or len(b) > 8:
                return False 
            if len(e) > 3:
                return False
            return True

    @property
    def name(self):
        b = ""
        #DOS allows spaces as long as they are
        #not trailing spaces, but
        #we forbid them here...
        #FIXME: Should we change this?
        for i in range(8):
            if self.nameRaw[i] == 32:
                break
            b += chr(self.nameRaw[i])
        
        e = ""
        for i in range(8,11):
            if self.nameRaw[i] == 32:
                break
            e += chr(self.nameRaw[i])
        
        if len(e) > 0:
            return b+"."+e
        else:
            return b
    
    @name.setter
    def name(self,value):
        b=""
        e=""
        #special cases
        if value == ".":
            b = ".       "
            e = "   "
        elif value == "..":
            b = "..      "
            e = "   "
        else:
            if not ShortDirEntry.isLegal(value):
                raise RuntimeError("Bad short filename")
            lst = value.split(".")
            b = lst[0]
            if len(lst) == 2:
                e=lst[1]
            else:
                e=""
        self.nameRaw = array.array("B",[32]*11)
        for i in range(len(b)):
            self.nameRaw[i] = ord(b[i])
        for i in range(len(e)):
            self.nameRaw[i+8] = ord(e[i])
            
    @property
    def isDirectory(self):
        return (self.attributes & self.DIRECTORY) != 0

    @property
    def isLabel(self):
        return (self.attributes & self.VOLUME) != 0
    @property
    def isFile(self):
        return (not self.isDirectory) and (not self.isLabel)

    @staticmethod
    def unparseDate( d ): #out ushort date, out ushort time, out byte deciseconds
        if type(d) == datetime.datetime:
            d = time.localtime(d.timestamp())
        year = d.tm_year-1980
        month = d.tm_mon
        day = d.tm_mday
        hr = d.tm_hour
        min = d.tm_min
        sec = d.tm_sec//2
        msec = 0 #d.tm_microsecond//1000
        tsec = ((d.tm_sec % 2 ) * 1000 + msec) // 200
        deciseconds = tsec
        T = ((hr << 11) | (min << 5) | (sec))
        date = ((year << 9) | (month << 5) | day)
        return date,T,deciseconds
    
    @property
    def created(self):
        return ShortDirEntry.parseDate(self.creationDateRaw,
            self.creationTimeRaw,self.creationTimeSecondsTenths)
    
    @created.setter
    def created(self,value):
        self.creationDateRaw, self.creationTimeRaw, self.creationTimeSecondsTenths = ShortDirEntry.unparseDate(value)
    
    @property
    def lastAccessed(self):
        return self.parseDate(self.lastAccessDateRaw, 0,0)
    
    @lastAccessed.setter
    def lastAccessed(self,value):
        self.lastAccessDateRaw, _, __ = self.unparseDate(value)
    
    @property
    def lastModified(self):
        return ShortDirEntry.parseDate(self.lastModifiedDateRaw,self.lastModifiedTimeRaw,0)
        
    @lastModified.setter
    def lastModified(self,value):
        self.lastModifiedDateRaw, self.lastModifiedTimeRaw, _ = ShortDirEntry.unparseDate(value)

    @property
    def firstCluster(self):
        return (self.clusterLow | (self.clusterHigh << 16))
        
    @firstCluster.setter
    def firstCluster(self,value):
        self.clusterLow = (value & 0xffff)
        self.clusterHigh = (value >> 16)

    @staticmethod
    def parseDate(d,t,tenmsec):
        year = (d >> 9) + 1980
        month = ((d >> 5) & 0xf) 
        day = (d & 0x1f)

        hour = ((t >> 11) & 0x1f)
        minute = (t >> 5) & 0x3f
        seci = t & 0x1f
        seci *= 2
        secf = seci + tenmsec * 0.01
        
        seconds = int(secf)
        millisec = int( (secf-seconds)*1000 )
        #round to nearest quarter second
        millisec = int(millisec//250)
        millisec *= 250
        return datetime.datetime( year=year, month=month, 
            day=day, hour=hour, 
            minute=minute, second=seconds, 
            microsecond=millisec*1000 )

  
    @staticmethod
    def getHeader():
        return "{0:8} {1:3} {4:5} {2:>7} {3:7} {5:<22} ".format(
            "Base",
            "Ext",
            "Size",
            "Cluster",
            "",
            "Last Modified",
            "YY",
            "ZZ"
        )
        #return "Base     Ext         Size Cluster Modified               "
    
    def __repr__(self):
        return str(self)
    
    def __str__(self):
        bse = ""
        ext = ""
        for i in range(8):
            bse += chr(self.nameRaw[i])
        for i in range(8,11):
            ext += chr(self.nameRaw[i])

        #          0=base, 1=ext, 2=size, 3=cluster, 4=attr
        #          5=created, 7=checksum
        
        attr=""
        if self.attributes & self.DIRECTORY:
            attr="<DIR>"
            
        return "{0:8} {1:3} {4:5} {2:7,d} {3:7,d} {5:<22}".format(
            bse, 
            ext, 
            self.size, 
            self.clusterHigh << 16 | self.clusterLow, 
            attr,
            str(self.created),
            str(self.lastModified),
            LFNEntry.computeFilenameChecksum(bse+ext)
        )

    def toBytes(self):
        A= (*self.nameRaw.tobytes(), self.attributes,0,
            self.creationTimeSecondsTenths,
            self.creationTimeRaw, self.creationDateRaw, self.lastAccessDateRaw,
            self.clusterHigh, self.lastModifiedTimeRaw, self.lastModifiedDateRaw,
            self.clusterLow, self.size)
        b = ShortDirEntry.S.pack( *A )
        assert len(b) == 32
        return b
         
    def markAsDeleted(self):
        self.nameRaw[0] = 0xe5





class LFNEntry:
    @property
    def deleted(self):
        return  (self.sequenceNumber & 0x80) == 0x80

    @property
    def last(self):
        return  (self.sequenceNumber & 0x40) == 0x40

    @property
    def seq(self):
        return self.sequenceNumber & 0x3f


    S = struct.Struct( "B10BBBB12BH4B" )

    def __init__(self,*args):
    
        #26 bytes of filename = 13 chars
        #high bit = deleted?, next bit = last?, next bits = number. Stored in reverse order
        # DL000000
        self.sequenceNumber = 0 #byte
        self.name0 = [0]*10  #5 chars, 10 bytes
        self.attribute = 15  #byte: always 15
        self.zero = 0  #byte
        self.checksum = 0 #byte
        self.name1 = [0]*12 #6 chars, 12 bytes
        self.alsozero = 0 #short
        self.name2 = [0]*4    #2 chars, 4 bytes
        #Total = 13 chars
        
        if len(args) == 2:
            b=args[0]
            idx=args[1]
            self.sequenceNumber = b[idx]
            idx+=1
            self.name0 = b[idx:idx+10]
            idx += 10;
            self.attribute = b[idx]
            idx+=1
            self.zero = b[idx]
            idx+=1
            self.checksum = b[idx]
            idx += 1
            self.name1 = b[idx:idx+12]
            idx += 12
            self.alsozero = b[idx]
            idx += 1
            self.alsozero |= (b[idx] << 8)
            idx += 1
            self.name2 = b[idx:idx+4]
            idx += 4
        elif len(args) == 5:
            seq,deleted,last,longnamepiece,csum = args
            if len(longnamepiece) > 13:
                raise RuntimeError("Bad long name piece: length={} value={}".format(
                    len(longnamepiece), longnamepiece) )
                    
            b = longnamepiece.encode("UTF-16LE")
            if len(b) > 26:
                raise RuntimeError("Bad long name piece 2: length={} value={}".format(
                    len(b), b) )
            b2 = [0]*26
            b2[0:len(b)] = b
            if( len(b) < len(b2) ):
                b2[len(b)] = 0
                b2[len(b) + 1] = 0
                for i in range(len(b)+2,len(b2)):
                    b2[i] = 0xff
        
            self.sequenceNumber = seq
            if deleted:
                self.sequenceNumber |= 0x80
            if last:
                self.sequenceNumber |= 0x40
            self.checksum = csum
            self.zero = 0
            self.alsozero = 0
            self.attribute = 0xf
            self.name0 = b2[0:len(self.name0)]
            self.name1 = b2[len(self.name0):len(self.name0)+len(self.name1)]
            self.name2 = b2[len(self.name0)+len(self.name1):len(self.name0)+len(self.name1)+len(self.name2)]
        else:
            assert 0

    @staticmethod
    def  makeEntries( longname, shortname):
        shortnamebase=""
        shortnameext=""
        idx = shortname.find('.');
        if(idx == -1):
            shortnamebase = shortname
            shortnameext = ""
        else:
            shortnamebase = shortname[0:idx]
            shortnameext = shortname[idx+1:]

        if len(shortnamebase) > 8:
            raise RuntimeError("Bad short name: "+str(shortnamebase))
        if len(shortnameext) > 3:
            raise RuntimeError("Bad short ext: "+str(shortnameext))
        while len(shortnamebase) < 8:
            shortnamebase += " "
            
        while len(shortnameext)  < 3:
            shortnameext += " "
            
        x = shortnamebase + shortnameext
        csum = LFNEntry.computeFilenameChecksum(x)

        pieces = []
        seq = 1;
        for i in range(0,len(longname),13):
            s = longname[i:i+13]
            ok, reason = LFNEntry.isLegal(s)
            if not ok:
                raise RuntimeError("Bad long name \""+s+"\": "+reason)
            pieces.append(LFNEntry(
                seq, 
                False,
                (i + 13) >= len(longname),
                s,
                csum))
            seq+=1
        pieces = list(reversed(pieces))
        return pieces

    legal = "+=[];,abcdefghijklmnopqrstuvwxyz "

    @staticmethod
    def isLegal(s):
        #LFN's also allow +=[];,.  and lowercase
        for c in s:
            if c not in ShortDirEntry.legal and c not in LFNEntry.legal:
                return False, "Character '" + c + "' is not valid"
        return True,""

    @staticmethod
    def computeFilenameChecksum(shortname):
        sum = 0
        for i in range(len(shortname)):
            low = sum & 1
            sum >>= 1
            if(low != 0):
                sum |= 0x80
            sum += ord(shortname[i])
            sum &= 0xff

        return sum & 0xff;

    def __repr__(self):
        return str(self)
        
    def __str__(self):
        b = self.name0 + self.name1 + self.name2
        j = len(b)
        for i in range(0,len(b),2):
            if( (b[i] == 0 and b[i + 1] == 0) or (b[i] == 0xff and b[i+1] == 0xff)):
                j = i
                break
        s = bytes(b[0:j]).decode("utf-16")
        return s   #">"+s+"("+j+f+")<";

    def toBytes(self):
        return LFNEntry.S.pack( self.sequenceNumber, *self.name0, self.attribute,
            self.zero, self.checksum, *self.name1, self.alsozero, *self.name2 )

    def markAsDeleted(self):
        self.sequenceNumber = 0xe5;

