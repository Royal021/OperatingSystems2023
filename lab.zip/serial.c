//serial.c

#include "serial.h"

void serial_init()
{
}

void serial_putc(char ch)
{
}