#pragma once

void serial_init();
void serial_putc(char ch);
