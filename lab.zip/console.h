#pragma once
#define CHAR_WIDTH 10
#define CHAR_HEIGHT 20
#define HEIGHT 600
void console_putc(unsigned char ch);