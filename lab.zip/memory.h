#pragma once

void memory_barrier();
