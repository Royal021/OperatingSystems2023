#pragma once

//need typedef for u32
#include "utils.h"

void video_init();
void video_draw_character(unsigned char ch, unsigned x, unsigned y);